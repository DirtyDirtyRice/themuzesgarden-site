"use client";

import { useEffect, useRef } from "react";

import type { TrackMatcherProPitchRuntimeState } from "../trackMatcherProPitchDspRuntime";

export function useTrackMatcherRuntimeRefs({
  runtimeA,
  runtimeB,
  fileUrlA,
  fileUrlB,
}: {
  runtimeA: TrackMatcherProPitchRuntimeState;
  runtimeB: TrackMatcherProPitchRuntimeState;
  fileUrlA: string | null;
  fileUrlB: string | null;
}) {
  const runtimeARef = useRef(runtimeA);
  const runtimeBRef = useRef(runtimeB);
  const fileUrlARef = useRef(fileUrlA);
  const fileUrlBRef = useRef(fileUrlB);

  useEffect(() => {
    runtimeARef.current = runtimeA;
  }, [runtimeA]);

  useEffect(() => {
    runtimeBRef.current = runtimeB;
  }, [runtimeB]);

  useEffect(() => {
    fileUrlARef.current = fileUrlA;
  }, [fileUrlA]);

  useEffect(() => {
    fileUrlBRef.current = fileUrlB;
  }, [fileUrlB]);

  return {
    runtimeARef,
    runtimeBRef,
    fileUrlARef,
    fileUrlBRef,
  };
}
