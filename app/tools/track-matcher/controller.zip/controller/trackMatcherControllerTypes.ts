export type TrackMode = "major" | "minor";

export type TrackMatcherDeckId = "A" | "B";

export type TrackMatcherTrackState = {
  bpm: number;
  keyIndex: number;
  mode: TrackMode;
  trackName: string;
  fileUrl: string | null;
};

export type SyncStatus = "idle" | "locked" | "adjusting" | "drifting";

export type SyncSnapshot = {
  status: SyncStatus;
  driftSeconds: number;
  phaseSeconds: number;
  bpmDifference: number;
  rateCorrection: number;
};

export type ControllerReadinessStatus =
  | "empty"
  | "loading"
  | "browser-only"
  | "pro-pitch-ready"
  | "failed";

export type ControllerDeckSnapshot = {
  deckId: TrackMatcherDeckId;
  title: string;
  trackName: string;
  fileLoaded: boolean;
  bpm: number;
  keyLabel: string;
  keyShiftSemitones: number;
  mode: TrackMode;
  runtimeStatus: "idle" | "unsupported" | "loading" | "ready" | "playing" | "paused" | "stopped" | "failed";
  readinessStatus: ControllerReadinessStatus;
  canUseProPitch: boolean;
  browserRate: number;
  effectiveRate: number;
  warning: string;
  detail: string;
};

export type ControllerEngineHealth = {
  status: ControllerReadinessStatus;
  label: string;
  detail: string;
  toneClasses: string;
};
